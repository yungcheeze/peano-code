#include "peano/grid/aspects/CellRefinement.h"


tarch::logging::Log peano::grid::aspects::CellRefinement::_log( "peano::grid::aspects::CellRefinement" );
